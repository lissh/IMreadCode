# -*- coding: utf-8 -*-
__author__ = 'lish'
from imxmlapi import *
from imjsonapi import *
